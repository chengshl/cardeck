#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v kotlinc >/dev/null || { echo 'STOP=KOTLINC_NOT_FOUND'; exit 2; }
build_dir="$(mktemp -d)"
trap 'rm -rf "$build_dir"' EXIT
kotlinc B233ResourceState.kt B233ResourceSessionFence.kt B233ResourceStateTest.kt B233ResourceSessionFenceTest.kt B233SocketOwnershipTest.kt B233ResourceIntegrationTest.kt B233AudioConfirmationGateTest.kt offline-test/Junit4Shim.kt offline-test/RunOffline.kt -include-runtime -d "$build_dir/offline-tests.jar"
java -jar "$build_dir/offline-tests.jar"
