#!/usr/bin/env python3
"""T104-v3 strict T101-only source patch. Dry-run by default, no commit or CI."""
from pathlib import Path
import argparse, hashlib, subprocess, difflib, sys

BASE='b2f311bfd7b07322e70f02001c8242394235c1ee'
EXPECTED_BLOB='b9ca644d628f7a66b35e07ac893a2b5266c86baf'
REL='app/src/main/java/io/github/shaonialife/cardeck/airplay/AirPlayClient.kt'

# No content from untrusted logs goes into the source. Each edit is a specific,
# unique literal anchored in the T101 code; fail closed if upstream changes.
EDITS=[
('''    private fun registerEventCommandChannel(
        socket: Socket,
        cipher: ControlCipher?,
    ) {
        eventCommandSocket = socket
        eventCommandCipher = cipher
    }''',
'''    private fun registerEventCommandChannel(
        socket: Socket,
        cipher: ControlCipher?,
    ) {
        if (endpoint.isBuickB233) {
            // Serialized with originating-socket checks on B233 event ACK.
            synchronized(eventCommandLock) {
                eventCommandSocket = socket
                eventCommandCipher = cipher
            }
        } else {
            eventCommandSocket = socket
            eventCommandCipher = cipher
        }
    }'''),
('''    private fun respondEventRequest(cseq: String?): Boolean {
        val socket = eventCommandSocket ?: return false
        val cipher = eventCommandCipher
        try {
            synchronized(eventCommandLock) {
                val head =''',
'''    private fun respondEventRequest(cseq: String?, originatingSocket: Socket? = null): Boolean {
        val socket = eventCommandSocket ?: return false
        try {
            synchronized(eventCommandLock) {
                // T104: a retired B233 event reader must never ACK on a replacement
                // event connection (nor consume its new encryption nonce).
                if (originatingSocket != null && eventCommandSocket !== originatingSocket) return false
                val cipher = eventCommandCipher
                val head ='''),
('''                            val acked = respondEventRequest(cseq)
                            if (endpoint.isBuickB233) audioControlLiveness.onEventAck(acked)''',
'''                            val acked = respondEventRequest(cseq, if (endpoint.isBuickB233) socket else null)
                            if (endpoint.isBuickB233) audioControlLiveness.onEventAck(acked)'''),
('''        contentType: String = "application/octet-stream",
        extraHeaders: List<Pair<String, String>> = emptyList(),
    ): Pair<String, ByteArray> {
        val client = socket ?: throw IOException("未连接")
        val startedAt''',
'''        contentType: String = "application/octet-stream",
        extraHeaders: List<Pair<String, String>> = emptyList(),
        expectedSocket: Socket? = null,
    ): Pair<String, ByteArray> {
        val client = socket ?: throw IOException("未连接")
        // T104: a queued B233 resource command may not attach to a replacement.
        // Existing callers leave this null and keep original wire behaviour.
        if (expectedSocket != null && client !== expectedSocket) throw IOException("RTSP 会话已更换")
        val startedAt'''),
('''        synchronized(rtspWriteLock) {
            cseq = ++cSeq
            // 先登记再写：响应可能在 write 返回前就到达''',
'''        synchronized(rtspWriteLock) {
            // Double-check at the actual write boundary. A pre-queue test alone
            // cannot prevent a reconnect between planning and socket capture.
            if (expectedSocket != null && socket !== expectedSocket) throw IOException("RTSP 会话已更换")
            cseq = ++cSeq
            // 先登记再写：响应可能在 write 返回前就到达'''),
]

def transform(raw:str)->str:
    for before, after in EDITS:
        if raw.count(before)!=1:
            raise ValueError(f'Patch context mismatch: expected exactly one occurrence, got {raw.count(before)} for {before[:70]!r}')
        raw=raw.replace(before,after,1)
    return raw

def check(repo:Path,apply:bool=False):
    repo=repo.resolve()
    if not (repo/'.git').exists():
        raise ValueError('Requires a normal full local git clone; never patch guessed or downloaded fragments')
    head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
    if head!=BASE:raise ValueError(f'STOP_HEAD_DRIFT: {head} != {BASE}')
    target=repo/REL
    if not target.is_file() or target.is_symlink():raise ValueError('STOP_FILE_MISSING_OR_SYMLINK')
    blob=subprocess.check_output(['git','-C',str(repo),'hash-object',str(target)],text=True).strip()
    if blob!=EXPECTED_BLOB:raise ValueError(f'STOP_BLOB_DRIFT: {blob} != {EXPECTED_BLOB}')
    content=target.read_text()
    updated=transform(content)
    diff=''.join(difflib.unified_diff(content.splitlines(True),updated.splitlines(True),
                 fromfile='a/'+REL,tofile='b/'+REL))
    print('T104_GUARD_PRECHECK=PASS')
    print('ORIGINAL_SHA256='+hashlib.sha256(content.encode()).hexdigest())
    print('DIFF_LINES='+str(len(diff.splitlines())))
    if apply:
        target.write_text(updated)
        print('T104_GUARD_APPLIED_LOCAL_ONLY=YES')
        print('NO_COMMIT_OR_PUSH_OR_APK=TRUE')
    else:
        print('T104_GUARD_DRY_RUN=PASS')
    return diff

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('repo',type=Path,help='exact T101 Git checkout')
    ap.add_argument('--apply',action='store_true',help='edit this local checkout only')
    ap.add_argument('--diff-out',type=Path,help='write unified diff after successful preflight')
    a=ap.parse_args()
    try:
        diff=check(a.repo,a.apply)
        if a.diff_out:a.diff_out.write_text(diff)
        else:print(diff)
    except (ValueError,OSError,subprocess.CalledProcessError) as err:
        print(f'T104_GUARD=STOP: {err}',file=sys.stderr)
        sys.exit(2)
