# T104-v6 生产准入检查 — 仍未通过

## 已确证（可以审计）

- 权威治理三分支 Blob 已在线复核一致；T101 分支 HEAD 未变。
- GitHub 真实 T101 两个目标 Kotlin 文件的 Blob 与早前值相同；v6 新增五个 T85/降级/退出代码锚点各唯一出现。
- 本地 43/43 Kotlin 合成用例 PASS；补丁合成转化、源锚点漂移阻断与 6 项 Python guard 用例通过。
- ZIP 及内部 SHA256 清单校验通过；工具默认 dry-run，不创建 GitHub commit、PR 或 APK。

## 还必须验证（不可隐瞒）

1. **完整 Git checkout**：网络受限，此执行环境无法解析 github.com。待授权执行端拿到真正的 T101 checkout 后执行脚本 dry-run / --apply，并审查预期 9 个文件、无额外改动；不能把 synthetic fixture 当作真实 T101 补丁已完成。
2. **真实 Android 测试**：必须在修改后的全部 App 源码上跑 `testDebugUnitTest`、`lintDebug`、`assembleDebug`，附精确 HEAD、差异与 Actions CI；此前 v5/v6 离线 shim 不能替代。
3. **T85 正确性**：本包确保 event `resource-2` 只能在 explicit audio POST transport-success 后发布，但原 T85 `statusLine.contains("200")` 没校验 bplist 应用级 `status`，尚不足以认定车机授予资源。音频失败/动态关闭/拆链与后台运行中 RTSP 写入并发还有竞态审查义务。
4. **会话原子性**：v5的 reader/cipher/expectedSocket 按身份保护；仍需严格验证控制 Socket 重新发布与旧线程之间的完整锁序及内存可见性。队列中已在发送的任务不能仅靠清空待办撤销。
5. **车机语义**：从受限证据核对 B233 `/info.modes`、TAKE/RELEASE/BORROW/UNBORROW/requestUI 真实字段；不公开源日志、设备地址、私有域名或凭据。
6. **公开 GitHub 提交身份**：作者与提交者须同为 `*@users.noreply.github.com`；现有 GitHub 连接写入接口不能显式指定，且仓库 AGENTS 规定用户实际验证后明确「提交」才 commit，故 STOP_PUBLIC_COMMIT_IDENTITY_UNVERIFIED。
7. **APK 门禁**：真实 CI 通过、代码审查、同签名且 versionCode 单调的单变量实验包，以及可保留数据的更高版本恢复包完整才允许小范围停车实车试验。不能重复让用户试 T101 已失败版本。

结论：#11 仍 P0 Open；T104-v6 是代码候选 + 离线测试，不是已修复且可安装的 CarDeck 版本。
