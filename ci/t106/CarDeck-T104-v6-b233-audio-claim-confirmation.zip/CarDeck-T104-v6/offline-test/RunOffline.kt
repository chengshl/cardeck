import org.junit.Test

fun main() {
    val testClasses = listOf(
        io.github.shaonialife.cardeck.airplay.B233ResourceStateTest::class.java,
        io.github.shaonialife.cardeck.airplay.B233ResourceStateHardeningTest::class.java,
        io.github.shaonialife.cardeck.airplay.B233ResourceStateOversizeTest::class.java,
        io.github.shaonialife.cardeck.airplay.B233ResourceAudioOwnershipTest::class.java,
        io.github.shaonialife.cardeck.airplay.B233ResourceSessionFenceTest::class.java,
        io.github.shaonialife.cardeck.airplay.B233SocketOwnershipTest::class.java,
        io.github.shaonialife.cardeck.airplay.B233ResourceIntegrationTest::class.java,
        io.github.shaonialife.cardeck.airplay.B233AudioConfirmationGateTest::class.java,
    )
    var passed = 0
    var failed = 0
    for (cls in testClasses) {
        val instance = cls.getDeclaredConstructor().newInstance()
        for (method in cls.declaredMethods.filter { it.isAnnotationPresent(Test::class.java) }.sortedBy { it.name }) {
            try {
                method.invoke(instance)
                println("PASS ${cls.simpleName}.${method.name}")
                passed++
            } catch (t: Throwable) {
                System.err.println("FAIL ${cls.simpleName}.${method.name}: ${t.cause ?: t}")
                failed++
            }
        }
    }
    println("OFFLINE_KOTLIN_TESTS passed=$passed failed=$failed")
    if (failed != 0) kotlin.system.exitProcess(1)
}
