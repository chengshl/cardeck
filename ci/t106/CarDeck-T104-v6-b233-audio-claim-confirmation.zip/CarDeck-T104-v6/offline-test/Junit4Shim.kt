package org.junit

/** Local offline-only shim; NOT to be included in the Android repository. */
@Target(AnnotationTarget.FUNCTION)
@Retention(AnnotationRetention.RUNTIME)
annotation class Test

object Assert {
    @JvmStatic
    fun assertTrue(value: Boolean) { if (!value) throw AssertionError("expected true") }
    @JvmStatic
    fun assertFalse(value: Boolean) { if (value) throw AssertionError("expected false") }
    @JvmStatic
    fun assertEquals(expected: Any?, actual: Any?) {
        if (expected != actual) throw AssertionError("expected=<$expected> actual=<$actual>")
    }
}
