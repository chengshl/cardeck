# CarDeck · T104-v6 — B233 主音频确认门禁

**状态：已完成并实测的离线 Kotlin/补丁生成器候选；尚未在 CarDeck 的完整 T101 Git checkout 上应用，也未做 Android Gradle / CI、Git commit、APK 或实车验证。**

## 真实基线

- 公共研发仓库：`chengshl/cardeck`，专项 Issue #11，状态 P0 Open。
- 权威治理：`Buick:docs/PROJECT-GOVERNANCE.md` v2.2，Git Blob `2242e007c99e65ddcffe67b53f850b3165f23aca`；Buick-E5/Test 的副本同 Blob。
- 签名实验 T101 精确 HEAD：`b2f311bfd7b07322e70f02001c8242394235c1ee`。
- 两个已有目标源码 Blob：AirPlayClient `b9ca644d628f7a66b35e07ac893a2b5266c86baf`；SessionController `b6d668738dc96d90ecbdf622cc77d8ec82c7763e`。
- 原 T101 实车错误：首 RTP 到 RTSP EOF 20.104 秒；同车 Link+ 长时 AAC 成功，不是与 T101 PCM 的单变量对照。

## v6 修复的具体问题

v5 的 `SessionController` 在 T85 `assertModes(true)` 之前就置 `b233AudioClaimPrepared=true`，但传给资源事件驱动的动态闭包把「准备申请」当作「允许在后续 `modesChanged` 发布 resource-2」。如果此时发生 `changeModes` / `requestUI`，B233 事件可能在确认声明之前重申主音频。

v6 把准备状态与明确声明成功状态分开：

1. `B233ResourceSessionFence` 按 control Socket + event Socket + generation 保存 `explicitAudioClaimConfirmed`，初始为 false。`plan` 即使收到 `claimAudio=true`，也只有确认过的会话才能将 resource-2 放进模式声明。
2. T85 **在发出主音频声明前**调用 `revokeB233ExplicitAudioClaim()`，把之前的许可和排队快照作废。
3. 只在原 T85 `assertModes(true)` 返回 transport 200 后，调用 `noteB233ExplicitAudioClaim()`。RTSP 非 200、抛异常、音频未建立、降级、主动音频撤销及会话替换均不能保留旧确认。
4. 同步修改事件闭包：原 `AirPlayModeClaims.claimAudio(...)` 必须再与 `eventOwner.hasB233ConfirmedAudioClaim()` 同时成立；资源事件不会替代 T85 原始、主动的 `assertModes`，从而保持原首次声明顺序。
5. 保留 v5 的 B233-only 事件 ACK、控制 Socket/RTSP reader 双重防护、后台有界单线程处理、旧会话世代门禁；非 B233 原路径不改。

**仍有风险**：T85 的 `transportOk` 只代表旧代码识别了 RTSP 200，不代表 bplist 业务 status 为成功；原状态与 `rtspWriteLock` 的全部跨线程原子性、接收端真实资源语义都仍需完整仓库审查。不能据此认定已经修复 20 秒 EOF。

## 本地可复核测试

```bash
bash run_offline_tests.sh
python3 test_t104_transform.py
python3 -m unittest -q test_guard_transform.py
python3 -m py_compile apply_socket_guard.py apply_t104_integration.py
sha256sum -c SHA256SUMS.txt
```

本轮本地执行 **43/43 Kotlin 离线测试 PASS**，包含7项新增「准备≠确认、成功确认、失败不确认、撤销旧队列、二次尝试重新确认、旧会话隔离、借用失败拒绝」用例；Python 合成变换通过、6项守卫测试通过。Kotlin 测试使用本包的 JUnit4 API shim 和反射驱动，并非 Android 原生 JUnit。

## 受控完整源码环境操作

```bash
# 准备一个全新 T101 独立工作目录（网络由获授权的执行端自行具备）
git clone https://github.com/chengshl/cardeck.git /path/to/cardeck-t104
cd /path/to/cardeck-t104
git checkout --detach b2f311bfd7b07322e70f02001c8242394235c1ee
# 先 dry-run + 人工审查 diff。脚本还核对真实 HEAD、Git Blob 和干净工作树。
python3 /path/to/THIS_BUNDLE/apply_t104_integration.py /path/to/cardeck-t104 --diff-out /tmp/t104-v6.diff
# 审查通过后才 --apply，不自动 commit/push
python3 /path/to/THIS_BUNDLE/apply_t104_integration.py /path/to/cardeck-t104 --apply --diff-out /tmp/t104-v6.diff
git status --short
./gradlew testDebugUnitTest
./gradlew :app:lintDebug
./gradlew assembleDebug
```

如任何锚点漂移、分支不符、Git Blob 不匹配、已有新增文件或工作树不干净，脚本 FAIL CLOSED。**不得**对稳定 Buick/E5 或 upstream main 应用；不得在尚未符合 noreply 作者/提交者与用户验证/提交约定前 commit。未复审签名/回退路径前不得发布或安装实验 APK。

## 文件列表

- `B233ResourceState.kt`、`B233ResourceSessionFence.kt` — 纯 Kotlin 资源模型与会话门禁
- 5份 Kotlin 合成单元测试，附 JUnit4 离线 shim/测试执行器
- `apply_socket_guard.py`、`apply_t104_integration.py` — 严格 T101 代码候选 patch 生成器
- Python 回归脚本、`run_offline_tests.sh`、`SHA256SUMS.txt`
- `PRODUCTION-GATE.md` — 尚未完成的 Android / GitHub / 实车门禁
