#!/usr/bin/env python3
"""T104-v6 B233-only integration candidate from EXACT signed T101 SHA.

DEFAULT DRY RUN. Fail closed on dirty checkout, wrong HEAD/blob or missing anchors.
Creates a local patch only, never creates a GitHub commit, APK, PR, or Release.
Run only after reviewing /mnt/data material; not designed for in-car deployment.
"""
from pathlib import Path
import argparse, difflib, hashlib, subprocess, sys
import apply_socket_guard

BASE=apply_socket_guard.BASE
CLIENT=apply_socket_guard.REL
SESSION='app/src/main/java/io/github/shaonialife/cardeck/SessionController.kt'
CLIENT_BLOB=apply_socket_guard.EXPECTED_BLOB
SESSION_BLOB='b6d668738dc96d90ecbdf622cc77d8ec82c7763e'
KOTLIN_PACKAGE='app/src/main/java/io/github/shaonialife/cardeck/airplay'
TEST_PACKAGE='app/src/test/java/io/github/shaonialife/cardeck/airplay'
HERE=Path(__file__).resolve().parent


def swap(raw, old, new, label):
    count=raw.count(old)
    if count!=1:
        raise ValueError('STOP_ANCHOR_'+label+': occurrences='+str(count))
    return raw.replace(old,new,1)


def client_transform(raw):
    # First apply the exact previous T104-v3 fixes (five literal anchors).
    raw=apply_socket_guard.transform(raw)
    # T101 request() calls startReader() BEFORE acquiring its write lock.
    # Guard the reader replacement itself against stale queued resource requests.
    raw=swap(raw,
"""        startReader(client)
        val queue = java.util.concurrent.LinkedBlockingQueue<Pair<String, ByteArray>>(1)""",
"""        startReader(client, expectedSocket)
        val queue = java.util.concurrent.LinkedBlockingQueue<Pair<String, ByteArray>>(1)""",'rtsp_reader_call')
    raw=swap(raw,
"""    private fun startReader(client: Socket) {
        val previous: Socket?
        synchronized(rtspWriteLock) {
            if (readerSocket === client && readerThread?.isAlive == true) return""",
"""    private fun startReader(client: Socket, expectedSocket: Socket? = null) {
        val previous: Socket?
        synchronized(rtspWriteLock) {
            // Check before swapping readers or closing the previous Socket.
            if (expectedSocket != null &&
                (client !== expectedSocket || socket !== expectedSocket)
            ) throw IOException("RTSP reader session changed")
            if (readerSocket === client && readerThread?.isAlive == true) return""",'rtsp_reader_switch')
    raw=swap(raw,
'''    @Volatile internal var b233AudioClaimPrepared: Boolean = false
''',
'''    @Volatile internal var b233AudioClaimPrepared: Boolean = false

    /** T104: one resource owner per B233 control + event Socket pair. */
    private data class B233ResourceBinding(
        val generation: Long,
        val controlSocket: Socket,
        val eventSocket: Socket,
    )

    private val b233ResourceFence = B233ResourceSessionFence()
    // Bounded: a nonresponsive receiver cannot allocate unbounded queued events.
    private val b233ResourceTx = java.util.concurrent.ThreadPoolExecutor(
        1, 1, 15L, java.util.concurrent.TimeUnit.SECONDS,
        java.util.concurrent.ArrayBlockingQueue<Runnable>(16),
        java.util.concurrent.ThreadFactory { task ->
            Thread(task, "b233-resource-tx").apply { isDaemon = true }
        },
        java.util.concurrent.ThreadPoolExecutor.AbortPolicy(),
    ).apply { allowCoreThreadTimeOut(true) }
    @Volatile private var b233ResourceBinding: B233ResourceBinding? = null

    /** A B233 event may only reassert mainAudio after this session confirmed T85's POST. */
    internal fun hasB233ConfirmedAudioClaim(): Boolean {
        if (!endpoint.isBuickB233) return false
        val binding = b233ResourceBinding ?: return false
        return b233ResourceFence.hasConfirmedAudioClaim(
            binding.generation, binding.controlSocket, binding.eventSocket,
        )
    }

    /** Invalidate queued modes replies before a new claim or video-only downgrade. */
    internal fun revokeB233ExplicitAudioClaim(): Boolean {
        if (!endpoint.isBuickB233) return false
        val binding = b233ResourceBinding ?: return false
        return b233ResourceFence.revokeLocalAudioClaim(
            binding.generation, binding.controlSocket, binding.eventSocket,
        )
    }

    /** Called only after the existing T85 mainAudio POST succeeded at transport level. */
    internal fun noteB233ExplicitAudioClaim(): Boolean {
        if (!endpoint.isBuickB233) return false
        val binding = b233ResourceBinding ?: return false
        return b233ResourceFence.noteLocalAudioClaim(
            binding.generation, binding.controlSocket, binding.eventSocket,
        )
    }

    /** Serialize a bounded resource snapshot to the captured control Socket only. */
    private fun sendB233ResourceSnapshot(
        snapshot: B233ResourceSessionFence.Snapshot,
        currentAudioClaim: () -> Boolean,
    ) {
        if (!b233ResourceFence.isLatest(snapshot)) return
        // An audio toggle while queued must not replay the old audio resource set.
        val containsAudio = snapshot.resources.any { it["resourceID"] == 2L }
        if (containsAudio != currentAudioClaim()) return
        val expected = snapshot.controlIdentity as? Socket ?: return
        val payload = BinaryPlist.encode(
            linkedMapOf(
                "type" to "modesChanged",
                "params" to linkedMapOf(
                    "appStates" to listOf(
                        linkedMapOf<String, Any?>("appStateID" to 2L, "entity" to 0L),
                        linkedMapOf<String, Any?>("appStateID" to 3L, "entity" to 0L),
                        linkedMapOf<String, Any?>("appStateID" to 1L, "entity" to 0L, "speechMode" to -1L),
                    ),
                    "resources" to snapshot.resources,
                ),
            ),
        )
        try {
            val (status, response) = request(
                "POST", "/command", payload,
                contentType = "application/x-apple-binary-plist",
                expectedSocket = expected,
            )
            // A 200 confirms only RTSP transport, not receiver resource acceptance.
            val transportOk = Regex("^(?:RTSP|HTTP)/[0-9.]+\\\\s+200(?:\\\\s|$)").containsMatchIn(status)
            log("AUDIO T104: B233 resource response transport200=$transportOk " +
                "bodyBytes=${response.size} businessAcceptance=unknown")
        } catch (error: IOException) {
            log("AUDIO T104: B233 resource command not sent/completed; type=${error.javaClass.simpleName}")
        }
    }
''','new_fields')
    # Ensure raw source still matches exactly the new v3 structure, replacing function signature / body.
    old='''    private fun registerEventCommandChannel(
        socket: Socket,
        cipher: ControlCipher?,
    ) {
        if (endpoint.isBuickB233) {
            // Serialized with originating-socket checks on B233 event ACK.
            synchronized(eventCommandLock) {
                eventCommandSocket = socket
                eventCommandCipher = cipher
            }
        } else {
            eventCommandSocket = socket
            eventCommandCipher = cipher
        }
    }'''
    new='''    private fun registerEventCommandChannel(
        socket: Socket,
        cipher: ControlCipher?,
    ): B233ResourceBinding? {
        if (!endpoint.isBuickB233) {
            eventCommandSocket = socket
            eventCommandCipher = cipher
            return null
        }
        val (previous, binding) = synchronized(eventCommandLock) {
            val old = b233ResourceBinding
            old?.let { b233ResourceFence.close(it.generation, it.controlSocket, it.eventSocket) }
            eventCommandSocket = socket
            eventCommandCipher = cipher
            val controlSocket = this.socket
            val next = if (controlSocket != null) {
                val initialModes = negotiatedInfo?.get("modes") as? Map<*, *>
                B233ResourceBinding(
                    b233ResourceFence.begin(controlSocket, socket, initialModes), controlSocket, socket,
                )
            } else null
            b233ResourceBinding = next
            old to next
        }
        // Retire a replaced event reader, without holding the command write lock.
        if (previous != null && previous.eventSocket !== socket) {
            runCatching { previous.eventSocket.close() }
        }
        return binding
    }'''
    raw=swap(raw,old,new,'register')

    # Avoid B233 senders capturing stale event socket/cipher before the shared lock.
    raw=swap(raw,
'''        return try {
            synchronized(eventCommandLock) {
                eventCseq++
                val body = BinaryPlist.encode(command)''',
'''        return try {
            synchronized(eventCommandLock) {
                // B233 must use a consistent Socket/cipher pair after replacement.
                val outgoingSocket = if (endpoint.isBuickB233) eventCommandSocket ?: return false else socket
                val outgoingCipher = if (endpoint.isBuickB233) eventCommandCipher else cipher
                eventCseq++
                val body = BinaryPlist.encode(command)''','post_event_guard')
    # Restrict replacements of these two lines to postEventCommand region before ACK fn.
    start=raw.index('    fun postEventCommand(')
    end=raw.index('    private fun respondEventRequest(',start)
    sec=raw[start:end]
    sec=swap(sec,'val bytes = cipher?.encrypt(plaintext) ?: plaintext',
             'val bytes = outgoingCipher?.encrypt(plaintext) ?: plaintext','post_cipher')
    sec=swap(sec,'socket.getOutputStream().apply {',
             'outgoingSocket.getOutputStream().apply {','post_socket')
    raw=raw[:start]+sec+raw[end:]

    # Reset binding and event socket only on B233 client close. Other car behaviour identical.
    raw=swap(raw,
'''        closeReverseAudioControlPort()
        runCatching { socket?.close() }
        socket = null''',
'''        closeReverseAudioControlPort()
        if (endpoint.isBuickB233) {
            val retiredEvent = synchronized(eventCommandLock) {
                val active = b233ResourceBinding
                active?.let { b233ResourceFence.close(it.generation, it.controlSocket, it.eventSocket) }
                b233ResourceBinding = null
                eventCommandSocket = null
                eventCommandCipher = null
                active?.eventSocket
            }
            runCatching { retiredEvent?.close() }
        }
        runCatching { socket?.close() }
        socket = null''','close_binding')

    # Keep trailing-lambda API compatibility; optionally pass B233 resource claim closure.
    raw=swap(raw,
'''    fun connectEventChannel(
        sessionKey: ByteArray?,
        setup: SetupInfo,
        onCommand: (Map<*, *>) -> Unit = {},
    )''',
'''    fun connectEventChannel(
        sessionKey: ByteArray?,
        setup: SetupInfo,
        b233ClaimAudio: (() -> Boolean)? = null,
        onCommand: (Map<*, *>) -> Unit = {},
    )''','connect_signature')
    raw=swap(raw,
'''            registerEventCommandChannel(socket, cipher)
            Thread({''',
'''            val b233Binding = registerEventCommandChannel(socket, cipher)
            val b233Driver = if (endpoint.isBuickB233 && b233Binding != null && b233ClaimAudio != null) {
                B233ResourceEventDriver(b233ResourceFence, b233ResourceTx) { snapshot ->
                    sendB233ResourceSnapshot(snapshot, b233ClaimAudio)
                }
            } else null
            Thread({''','event_setup')
    raw=swap(raw,
'''                            try {
                                onCommand(command)
                            } catch (error: Exception) {
                                log("EVENT: 命令处理异常 - ${error.message}")
                            }''',
'''                            val resourceType = command["type"] as? String
                            if (endpoint.isBuickB233 && b233Binding != null && b233Driver != null &&
                                (resourceType == "changeModes" || resourceType == "requestUI")
                            ) {
                                if (resourceType == "changeModes") auditB233ModeRequest(command)
                                if (acked) {
                                    val claimAudio = runCatching { b233ClaimAudio?.invoke() == true }.getOrDefault(false)
                                    val enqueued = b233Driver.onEvent(
                                        b233Binding.generation, b233Binding.controlSocket,
                                        socket, command, claimAudio,
                                    )
                                    if (!enqueued) log("AUDIO T104: resource plan skipped or queue rejected")
                                } else {
                                    log("AUDIO T104: resource request skipped after failed event ACK")
                                }
                                // No synchronous assertModes on the event reader for B233.
                                continue
                            }
                            try {
                                onCommand(command)
                            } catch (error: Exception) {
                                log("EVENT: 命令处理异常 - ${error.message}")
                            }''','event_dispatch')
    # safe reconnect requires stale binding to be retired even if client.close not called;
    # the request expectedSocket double-check remains the last boundary.
    return raw


def session_transform(raw):
    raw=swap(raw,
'''                            client.connectEventChannel(sessionKey, setup) { command ->''',
'''                            // T104 B233 resource state is bound to this *actual* AirPlayClient.
                            val eventOwner = client
                            eventOwner.connectEventChannel(sessionKey, setup, b233ClaimAudio = {
                                io.github.shaonialife.cardeck.airplay.AirPlayModeClaims.claimAudio(
                                    eventOwner.currentEndpoint.isBuickB233,
                                    audioEnabledForSession,
                                    b233AudioClaimPrepared = eventOwner.b233AudioClaimPrepared,
                                ) && eventOwner.hasB233ConfirmedAudioClaim()
                            }) { command ->''','session_connect')
    raw=swap(raw,
'''                                    "changeModes" -> {
                                        // T84 numeric-only, bounded evidence before existing T26 behavior.''',
'''                                    "changeModes" -> {
                                        // B233 is handled asynchronously by AirPlayClient with
                                        // the original event Socket + generation. Legacy unchanged.
                                        if (!client.currentEndpoint.isBuickB233) {
                                        // T84 numeric-only, bounded evidence before existing T26 behavior.''','session_modes_open')
    raw=swap(raw,
'''                                        client.assertModes(claimAudioResource = claimAudio)
                                    }

                                    else ->''',
'''                                        client.assertModes(claimAudioResource = claimAudio)
                                        }
                                    }

                                    else ->''','session_modes_end')
    raw=swap(raw,
'''                    client.b233AudioClaimPrepared = false
                    appendLog("AUDIO T85: mainAudio declaration unconfirmed; skip audio SETUP, keep video")
                    return false
                }
            }
            // SETUP 失败不会扰动会话''',
'''                    client.b233AudioClaimPrepared = false
                    appendLog("AUDIO T85: mainAudio declaration unconfirmed; skip audio SETUP, keep video")
                    return false
                }
                // Mark only the existing, explicitly successful audio claim;
                // do not let generic changeModes events reclaim mainAudio.
                client.noteB233ExplicitAudioClaim()
            }
            // SETUP 失败不会扰动会话''','audio_claim')
    # T104-v6: exact T101 anchors, additions after v5's generated code.
    raw=swap(raw,
'''                client.b233AudioClaimPrepared = true
                val transportOk = client.assertModes(claimAudioResource = true)''',
'''                client.revokeB233ExplicitAudioClaim()
                client.b233AudioClaimPrepared = true
                val transportOk = client.assertModes(claimAudioResource = true)''','audio_attempt_reset')
    raw=swap(raw,
'''                    client.b233AudioClaimPrepared = false
                    appendLog("AUDIO T85: mainAudio declaration unconfirmed; skip audio SETUP, keep video")''',
'''                    client.b233AudioClaimPrepared = false
                    client.revokeB233ExplicitAudioClaim()
                    appendLog("AUDIO T85: mainAudio declaration unconfirmed; skip audio SETUP, keep video")''','audio_failed_reset')
    raw=swap(raw,
'''        client.b233AudioClaimPrepared = false
        // Mark video-only intent first''',
'''        client.b233AudioClaimPrepared = false
        client.revokeB233ExplicitAudioClaim()
        // Mark video-only intent first''','audio_no_setup_reset')
    raw=swap(raw,
'''                                                audioEnabledForSession = false
                                                audioAutoDowngradedForSession = true
                                                val videoOnlyClaimed =''',
'''                                                audioEnabledForSession = false
                                                audioAutoDowngradedForSession = true
                                                client.revokeB233ExplicitAudioClaim()
                                                val videoOnlyClaimed =''','audio_teardown_reset')
    raw=swap(raw,
'''                                                        audioEnabledForSession = false
                                                        audioAutoDowngradedForSession = true
                                                        appendLog(''',
'''                                                        audioEnabledForSession = false
                                                        audioAutoDowngradedForSession = true
                                                        client.revokeB233ExplicitAudioClaim()
                                                        appendLog(''','audio_disconnect_reset')
    return raw


def git(repo,*args):
    return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()


def build(repo:Path,apply:bool):
    repo=repo.resolve()
    if not (repo/'.git').exists():raise ValueError('STOP_NOT_GIT_CHECKOUT')
    if git(repo,'rev-parse','HEAD')!=BASE:raise ValueError('STOP_BASE_DRIFT')
    if git(repo,'status','--porcelain'):raise ValueError('STOP_DIRTY_CHECKOUT')
    targets=[(CLIENT,CLIENT_BLOB,client_transform),(SESSION,SESSION_BLOB,session_transform)]
    changes={}
    for rel,blob,trans in targets:
        path=repo/rel
        if not path.is_file() or path.is_symlink():raise ValueError('STOP_FILE_MISSING_OR_LINK '+rel)
        if git(repo,'hash-object',str(path))!=blob:raise ValueError('STOP_BLOB_DRIFT '+rel)
        content=path.read_text()
        updated=trans(content)
        changes[rel]=(content,updated)
    for local_rel,repo_rel in [
        ('B233ResourceState.kt',KOTLIN_PACKAGE+'/B233ResourceState.kt'),
        ('B233ResourceSessionFence.kt',KOTLIN_PACKAGE+'/B233ResourceSessionFence.kt'),
        ('B233ResourceStateTest.kt',TEST_PACKAGE+'/B233ResourceStateTest.kt'),
        ('B233ResourceSessionFenceTest.kt',TEST_PACKAGE+'/B233ResourceSessionFenceTest.kt'),
        ('B233SocketOwnershipTest.kt',TEST_PACKAGE+'/B233SocketOwnershipTest.kt'),
        ('B233ResourceIntegrationTest.kt',TEST_PACKAGE+'/B233ResourceIntegrationTest.kt'),
        ('B233AudioConfirmationGateTest.kt',TEST_PACKAGE+'/B233AudioConfirmationGateTest.kt'),
    ]:
        target=repo/repo_rel
        if target.exists() or target.is_symlink():raise ValueError('STOP_EXISTING_FILE '+repo_rel)
        changes[repo_rel]=('',(HERE/local_rel).read_text())
    patches=[]
    for rel,(before,after) in changes.items():
        patches.append(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
          fromfile=('/dev/null' if not before else 'a/'+rel),tofile='b/'+rel)))
    diff=''.join(patches)
    if apply:
        for rel,(_,after) in changes.items():
            target=repo/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(after)
    return diff,len(changes)

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('repo',type=Path)
    ap.add_argument('--apply',action='store_true',help='Write verified local checkout; still no GitHub writes')
    ap.add_argument('--diff-out',type=Path)
    args=ap.parse_args()
    try:
        diff,num=build(args.repo,args.apply)
        print('T104_V6_PREFLIGHT=PASS')
        print('FILE_SCOPE='+str(num))
        print('LOCAL_APPLIED='+str(args.apply))
        print('NO_GIT_COMMIT_OR_PUBLISH=TRUE')
        if args.diff_out:
            args.diff_out.write_text(diff)
            print('DIFF_FILE='+str(args.diff_out))
        else:print(diff)
    except (OSError,subprocess.CalledProcessError,ValueError) as ex:
        print('T104_V6=STOP '+str(ex),file=sys.stderr)
        sys.exit(2)
