#!/usr/bin/env python3
"""Synthetic-anchor transform test, NOT compilation of real CarDeck.

The exact full-file git-blob preflight is only performed by apply_t104_integration.py
on the user's verified T101 checkout. Synthetic fixtures check replacement logic.
"""
import ast
from pathlib import Path
import apply_socket_guard as prior
import apply_t104_integration as t104


def old_literals(function):
    src=Path(t104.__file__).read_text()
    tree=ast.parse(src)
    fn=next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name==function)
    out=[]
    for n in ast.walk(fn):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id=='swap' and len(n.args)>=4:
            try:
                out.append((ast.literal_eval(n.args[1]),ast.literal_eval(n.args[3])))
            except Exception:pass
    return out


client_fragments=[]
for before,_ in prior.EDITS:
    client_fragments.append(before)
for before,label in old_literals('client_transform'):
    if label in {'post_cipher','post_socket','post_event_guard'}:continue
    client_fragments.append(before)
# The current postEventCommand range must contain both cipher and socket outputs.
client_fragments.insert(1, '''    fun postEventCommand(command: Map<String, Any?>): Boolean {
        val socket = eventCommandSocket ?: return false
        val cipher = eventCommandCipher
        return try {
            synchronized(eventCommandLock) {
                eventCseq++
                val body = BinaryPlist.encode(command)
                val bytes = cipher?.encrypt(plaintext) ?: plaintext
                socket.getOutputStream().apply {
                    write(bytes)
                    flush()
                }
            }
        } catch (error: IOException) { false }
    }
''')
client='\n\n'.join(client_fragments)
assert client.count('fun postEventCommand')==1
result=t104.client_transform(client)
assert result.count('private val b233ResourceFence = B233ResourceSessionFence()')==1
assert result.count('expectedSocket: Socket? = null')==2
assert result.count('b233ResourceFence.begin(controlSocket, socket, initialModes)')==1
assert result.count('sendB233ResourceSnapshot(snapshot, b233ClaimAudio)')==1
assert result.count('if (!client.currentEndpoint.isBuickB233)')==0
assert 'ArrayBlockingQueue<Runnable>(16)' in result
assert 'allowCoreThreadTimeOut(true)' in result
assert result.count('startReader(client, expectedSocket)')==1
assert result.count('private fun startReader(client: Socket, expectedSocket: Socket? = null)')==1
assert result.index('if (expectedSocket != null &&\n                (client !== expectedSocket || socket !== expectedSocket)') < result.index('if (readerSocket === client')
assert 'outgoingCipher?.encrypt(plaintext)' in result
assert 'outgoingSocket.getOutputStream()' in result

session='\n\n'.join(before for before,label in old_literals('session_transform') if label != 'audio_failed_reset')
new=t104.session_transform(session)
assert new.count('eventOwner.connectEventChannel')==1
assert new.count('client.noteB233ExplicitAudioClaim()')==1
assert new.count('client.revokeB233ExplicitAudioClaim()')==5
assert 'eventOwner.hasB233ConfirmedAudioClaim()' in new
assert new.count('if (!client.currentEndpoint.isBuickB233)')==1

# A source drift (even one character) must fail rather than silently skip a patch.
assert_exceptions=0
for bad,transform in [
    (client.replace('    private fun registerEventCommandChannel(', '    private fun zregisterEventCommandChannel(',1),t104.client_transform),
    (session.replace('                            client.connectEventChannel(', '                            client.connectEventChannelX(',1),t104.session_transform),
]:
    try:
        transform(bad)
        raise AssertionError('unexpected pass on drift')
    except ValueError:
        assert_exceptions+=1
assert assert_exceptions==2
print('T104_V6_SYNTHETIC_TRANSFORM=PASS')
print('T104_V6_EXPECTED_FILES=9')
print('T104_V6_ANCHOR_DRIFT_FAIL_CLOSED=PASS')
print('REAL_T101_SOURCE_COMPILE=NOT_RUN')
