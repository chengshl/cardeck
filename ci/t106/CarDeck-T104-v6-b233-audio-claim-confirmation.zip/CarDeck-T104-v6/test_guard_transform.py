import importlib.util, unittest
from pathlib import Path
P=Path(__file__).with_name('apply_socket_guard.py')
spec=importlib.util.spec_from_file_location('t104_guard',P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class ExactGuardTransform(unittest.TestCase):
    def test_all_exact_contexts_one_each(self):
        src='\n'.join(a for a,b in m.EDITS)
        dst=m.transform(src)
        for a,b in m.EDITS:
            self.assertIn(b,dst)
            self.assertNotIn(a,dst)
    def test_already_applied_fails_closed(self):
        src='\n'.join(a for a,b in m.EDITS)
        with self.assertRaises(ValueError):m.transform(m.transform(src))
    def test_missing_anchor_fails_closed(self):
        src='\n'.join(a for a,b in m.EDITS[:-1])
        with self.assertRaises(ValueError):m.transform(src)
    def test_original_other_receivers_remain_default(self):
        src='\n'.join(a for a,b in m.EDITS)
        out=m.transform(src)
        self.assertIn('originatingSocket: Socket? = null',out)
        self.assertIn('if (endpoint.isBuickB233) socket else null',out)
        self.assertIn('expectedSocket: Socket? = null',out)
    def test_lock_protects_register_pair(self):
        out=m.transform("\n".join(a for a,b in m.EDITS))
        self.assertIn("if (endpoint.isBuickB233) {\n            // Serialized with originating-socket checks",out)
        self.assertIn("synchronized(eventCommandLock) {\n                eventCommandSocket = socket\n                eventCommandCipher = cipher",out)
    def test_lock_protects_return_and_nonce(self):
        out=m.transform('\n'.join(a for a,b in m.EDITS))
        self.assertLess(out.index('if (originatingSocket != null'),out.index('val cipher = eventCommandCipher'))
        self.assertLess(out.index('if (expectedSocket != null && socket !== expectedSocket)'),out.index('cseq = ++cSeq'))
if __name__=='__main__': unittest.main(verbosity=2)
